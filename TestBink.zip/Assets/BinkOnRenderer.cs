﻿using UnityEngine;

namespace BlackJack.ProjectF.Client
{
    /// <summary>
    /// Bink视频播放在材质上。
    /// </summary>
    public class BinkOnRenderer : BinkPlayer
    {
        private void Start()
        {
            Play(m_file);
        }

#if UNITY_EDITOR
        private void OnEnable()
        {
            Play(m_file);
        }
#endif

        /// <summary>
        /// 视频开始了
        /// </summary>
        /// <param name="video"></param>
        protected override void OnPlayBegin()
        {
            var rd = GetComponent<Renderer>();
            if (rd == null)
            {
                return;
            }

            var mats = rd.materials;
            if (m_matIndex >= 0)
            {
                if (m_matIndex < mats.Length)
                {
                    mats[m_matIndex].SetTexture(m_mainTexName, m_rt);
                }
            }
            else
            {
                foreach (var mat in rd.materials)
                {
                    mats[m_matIndex].SetTexture(m_mainTexName, m_rt);
                }
            }
        }

        public string m_mainTexName = "_BaseMap";
        public int m_matIndex;
    }
}
