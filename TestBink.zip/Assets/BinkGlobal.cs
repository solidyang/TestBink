﻿using BinkPlugin;
using UnityEngine;
using System.Collections;

namespace BlackJack.ProjectF.Client
{
    /// <summary>
    /// Bink VideoPlayer组件播放视频
    /// </summary>
    public class BinkGlobal : Utils.MonoSingleton<BinkGlobal>
    {
        public void IncreaseBinkInstance()
        {
            if (m_co == null)
            {
                m_co = StartCoroutine("EndOfFrame");
            }

            ++m_count;
        }

        public void DecreaseBinkInstance()
        {
            --m_count;
            if (m_count == 0)
            {
                StopCoroutine("EndOfFrame");
                m_co = null;

                // Issue a plugin event to close any binks
                GL.IssuePluginEvent(Bink.GetUnityEventFunc(), (int)BinkUnity.UnityPluginCommands.ProcessCloses);
            }
        }

        private IEnumerator EndOfFrame()
        {
            Debug.Log("BinkGlobal.EndOfFrame start.");
            
            while (true)
            {
                // Wait until all frame rendering is done
                yield return new WaitForEndOfFrame();

                // Tell Bink that we have scheduled everything that we are going to	 
                Bink.AllScheduled();

                Bink.SetOverlayRenderBuffer(Display.main.colorBuffer.GetNativeRenderBufferPtr(), Display.main.renderingWidth, Display.main.renderingHeight);

                // Issue a plugin event to process and draw binks
                {
                    RenderTexture savedRT = RenderTexture.active;
                    RenderTexture.active = null;
#if (UNITY_IOS) || (UNITY_EDITOR_OSX) || (UNITY_STANDALONE_OSX) || (BINK_TVOS)
                    GL.IssuePluginEvent(Bink.GetUnityEventFunc(), (int)BinkUnity.UnityPluginCommands.ProcessNoWait);
                    GL.IssuePluginEvent(Bink.GetUnityEventFunc(), (int)BinkUnity.UnityPluginCommands.Draw);
#else
                    GL.IssuePluginEvent(Bink.GetUnityEventFunc(), (int)BinkUnity.UnityPluginCommands.Draw);
                    GL.IssuePluginEvent(Bink.GetUnityEventFunc(), (int)BinkUnity.UnityPluginCommands.ProcessNoWait);
#endif
                    RenderTexture.active = savedRT;
                }
            }
        }

        private Coroutine m_co = null;
        private int m_count = 0;
    }
}
