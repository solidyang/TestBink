/* vim: set softtabstop=2 shiftwidth=2 expandtab : */
using System;
using System.Collections.Generic;
using UnityEngine;
using BinkPlugin;

public class BinkImageUnity : MonoBehaviour
{
  [SerializeField]
  public string binkname;

  void Start()
  {
    Renderer renderer = GetComponent<Renderer>();
    renderer.material.SetTexture("_MainTex", Bink.CreateImage(binkname, true, true));
  }
}