﻿using UnityEngine;

namespace BlackJack.ProjectF.Utils
{
	/// <summary>
	/// MonoBehaviour单件 （会自动创建组件对象）
	/// </summary>
	/// <typeparam name="T"></typeparam>
    public class MonoSingleton<T> : MonoBehaviour where T : MonoSingleton<T>
    {
        protected virtual void Initialize() { }
        protected virtual void Uninitialize() { }

		/// <summary>
		/// 创建实例
		/// </summary>
        private static void CreateInstance()
		{
			GameObject go = null;
            if (m_instance == null)
            {
                go = GameObject.Find(typeof(T).Name);
	            if (go == null)
	            {
		            go = new GameObject(typeof(T).Name);
		            go.hideFlags = HideFlags.DontSave;
	            }

#if UNITY_EDITOR
                if (Application.isPlaying)
                {
	                DontDestroyOnLoad(go);
                }
#else
				DontDestroyOnLoad(go);
#endif
            }

            if (m_instance == null && go != null)
            {
                m_instance = go.GetComponent<T>();
                if (m_instance == null)
                {
                    m_instance = go.AddComponent<T>();
                }
                if (m_instance is MonoSingleton<T>)
                {
                    MonoSingleton<T> obj = m_instance;
                    obj.Initialize();
                }
                else
                {
                    Destroy(m_instance);
                    m_instance = default(T);
                }
                if (m_instance != null)
                {
                    //不做这一步则不走update函数，暂时不知道原因
                    m_instance.enabled = false;
                    m_instance.enabled = true;
                }
            }
        }

		/// <summary>
		/// 删除
		/// </summary>
        public static void DestroyInstance()
        {
            if (m_instance != null)
            {
                m_instance.Uninitialize();
                Destroy(m_instance);
                m_instance = default(T);
            }
        }

        /// <summary>
        /// 直接获得instance,用于在关闭等不需要资源存在的地方
        /// </summary>
        public static T InstanceWithoutRecreation
        {
            get { return m_instance; }
        }
		/// <summary>
		/// Instance
		/// </summary>
        public static T Instance
        {
            get
            {
                if (m_instance == null)
                {
	                CreateInstance();
                }

	            return m_instance;
            }
        }

		protected virtual void Awake()
		{
			if (m_instance != null)
			{
                Debug.Log($"{typeof(T).Name} has already instanced ({m_instance.name}).");
			}
			else
			{
				m_instance = (T)this;
            }
		}
		

		#region 成员
		/// <summary>
		/// 实例
		/// </summary>
		protected static T m_instance;
	    #endregion 成员
	}
}
