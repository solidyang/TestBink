﻿using BinkPlugin;
using UnityEngine;
using System;
using System.IO;
using System.Threading;
using UnityEngine.Networking;


namespace BlackJack.ProjectF.Client
{
    /// <summary>
    /// 播放BINK视频到RenderTexture上。ref: class BinkUnity
    /// </summary>
    public class BinkPlayer : MonoBehaviour
    {
        public void Play(string cgResPath)
        {
            m_file = cgResPath;

#if UNITY_ANDROID
            string fullPath = $"{Application.persistentDataPath}/{m_file}";
            if (!File.Exists(fullPath))
            {
                var request = UnityWebRequest.Get($"{Application.streamingAssetsPath}/{m_file}");
                request.SendWebRequest();
                while (!request.isDone)
                {
                    Thread.Sleep(1);
                }

                File.WriteAllBytes(fullPath, request.downloadHandler.data);
            }
#else
            string fullPath = $"{Application.streamingAssetsPath}/{m_file}";
#endif
            Debug.Log($"BinkPlayer.PlayCG({fullPath})");

            IntPtr bink = Bink.Open(fullPath, m_soundOutput, 0, m_ioBuffering, 0);
            if (bink == IntPtr.Zero)
            {
                string s = Bink.GetError();
                Debug.LogError($"[Bink.Open] {s}");
                OnPlayEnd();
                return;
            }

            Debug.Log($"[Bink.Open] Success! {bink}");
            // Stop previous bink
            if (m_bink != IntPtr.Zero)
            {
                Stop();
            }

            m_bink = bink;

            Bink.GetInfo(m_bink, ref m_info);

            Debug.Log($"Bink Info: Frames = {m_info.Frames}, Size = {m_info.Width}x{m_info.Height}, FPS = {m_info.FrameRate}, SoundTrac = {m_info.SndTrackType}.");

            Bink.Loop(m_bink, (uint)(m_loop ? 0 : 1));

            if (m_rt == null || m_rt.width != m_info.Width || m_rt.height != m_info.Height)
            {
                if (m_rt != null)
                {
                    Destroy(m_rt);
                    m_rt = null;
                }

                //m_rt = Resources.Load<RenderTexture>("BinkRenderTarget");
                if (m_rt == null)
                {
                    m_rt = new RenderTexture((int)m_info.Width, (int)m_info.Height, 0/*, RenderTextureFormat.ARGBHalf*/);
                    Debug.Log($"Create RenderTexture for BINK! {m_rt}");
                }

                if (m_rt != null && !m_rt.IsCreated())
                {
                    m_rt.Create();
                }
            }

            if (m_rt == null)
            {
                Stop();
                OnPlayEnd();
                return;
            }

            var renderer = GetComponent<Renderer>();
            if (renderer)
            {
                renderer.material.mainTexture = m_rt;
            }

            //m_audioSrc.volume = 0.5f;
            //m_audioSrc.minDistance = 99999;
            //m_audioSrc.maxDistance = 999999;

            BinkGlobal.Instance.IncreaseBinkInstance();

            if (!enabled)
            {
                enabled = true;
            }

            OnPlayBegin();
        }

        public void Stop()
        {
            if (m_bink != IntPtr.Zero)
            {
                OnEnd();
            }
        }

        public static void Destroy(UnityEngine.Object obj)
        {
            if (obj != null)
            {
#if UNITY_EDITOR
                if (Application.isPlaying)
                    UnityEngine.Object.Destroy(obj);
                else
                    UnityEngine.Object.DestroyImmediate(obj);
#else
                UnityEngine.Object.Destroy(obj);
#endif
            }
        }

        public bool IsPlaying => m_bink != IntPtr.Zero;

#region 私有方法

        protected virtual void OnPlayBegin()
        {

        }

        protected virtual void OnPlayEnd()
        {

        }

        private void OnEnd()
        {
            if (m_bink != IntPtr.Zero)
            {
                BinkGlobal.Instance.DecreaseBinkInstance();

                enabled = false;

                Bink.Close(m_bink);
                m_bink = IntPtr.Zero;

                OnPlayEnd();
            }
        }

        private void Start()
        {
#if (UNITY_SWITCH) || (UNITY_IOS) // NX requires a special call to regsiter the plugin with unity (only do this once pls)
            Bink.RegisterPlugin();
#endif
        }

        private void Update()
        {
            if (m_doPlay)
            {
                m_doPlay = false;
                Play(m_file);
            }

            if (m_bink == IntPtr.Zero)
            {
                return;
            }

            //uint draw_flags = forceDrawSRGB ? (uint)Bink.DrawFlags.DecodeSRGB : 0;
            uint draw_flags = (uint)Bink.DrawFlags.DecodeSRGB;

            // draw it
            // make sure the render texture exists
            if (m_ourCachedNativeTargetTexture == IntPtr.Zero)
            {
                m_ourCachedNativeTargetTexture = m_rt.GetNativeTexturePtr();
            }

            Bink.SetDrawFlags(m_bink, draw_flags);

            // now tell Bink to draw to it
            Bink.ScheduleToTexture(m_bink, 0, 0, 1, 1, 0, m_ourCachedNativeTargetTexture, (uint)m_rt.width, (uint)m_rt.height);

            Bink.GetInfo(m_bink, ref m_info);

            Debug.Log($"Bink Frame = {m_info.FrameNum}/{m_info.Frames}, size = {m_info.Width}*{m_info.Height}");
            if (!m_loop && m_info.FrameNum != UInt32.MaxValue && m_info.FrameNum >= m_info.Frames)
            {
                OnEnd();
            }
        }

        private void OnDisable()
        {
            Stop();
        }

        private void OnDestroy()
        {
            Stop();

            if (m_rt != null)
            {
                Destroy(m_rt);
            }
        }

#endregion

        public string m_file;
        public bool m_loop;

        public Bink.BufferingTypes m_ioBuffering = Bink.BufferingTypes.Stream;
        public Bink.SoundTrackTypes m_soundOutput = Bink.SoundTrackTypes.SndSimple;

        protected IntPtr m_bink = IntPtr.Zero;
        protected IntPtr m_ourCachedNativeTargetTexture = IntPtr.Zero;
        protected Bink.Info m_info;
        protected RenderTexture m_rt;

        protected AudioSource m_audioSrc;

        public bool m_doPlay;
    }
}
